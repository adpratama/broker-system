<?php $__env->startSection('content'); ?>
<section class="section">
   <div class="section-body">

      <div class="row">
         <div class="col-12">
         <div class="card">

            
            <div class="card-header">
               <div class="col-sm-12 col-md-6">
               <h4>Daftar Jenis Mata Uang</h4>
               </div>
               <div class="col-sm-12 col-md-6">
               <a href="<?php echo e(route('currency.create')); ?> " 
                  class="btn btn-light float-right" >
                  Tambah
               </a> 
               </div>
            </div>

            
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                     <thead>
                        <tr>
                        <th>No</th>
                        <th>Kode Mata Uang</th>
                        <th>Nama Mata Uang</th>
                        <th>Tindakan</th>
                        </tr>
                     </thead>
                     
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         </div>
      </div>
   </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script>
$("#table-1").dataTable({
"columnDefs": [
   { "sortable": false, "targets": [2,3] }
]
});
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/broker-system/resources/views/pages/dashboard/index.blade.php ENDPATH**/ ?>