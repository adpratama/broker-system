
<div class="sidebar-brand">
  <a href="index.html">urunproteksi.com</a>
</div>

<div class="sidebar-brand sidebar-brand-sm">
  <a href="index.html">UP</a>
</div>

<ul class="sidebar-menu">

  
  <li>
    <a class="nav-link" href="<?php echo e(route('dashboard.index')); ?> ">
      <i class="fas fa-tachometer-alt"></i> 
      <span>Dashboard</span>
    </a>
  </li>

  
  <li class="menu-header">Data Master</li>
  <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown">
      <i class="fas fa-database"></i>
      <span>Data Master</span>
    </a>
    <ul class="dropdown-menu">
      <li>
        <a class="nav-link" href="<?php echo e(route('clients.index')); ?>">
          Client / Insured
        </a>
      </li>
      <li>
        <a class="nav-link" href="<?php echo e(route('insurance.index')); ?>">
          Insurance
        </a>
      </li>
      <li>
        <a class="nav-link" href="<?php echo e(route('cover_type.index')); ?>">
          Jenis Asuransi
        </a>
      </li>
      <li>
        <a class="nav-link" href="<?php echo e(route('authorize_sign.index')); ?>">
          Authorize Sign
        </a>
      </li>
      <li>
        <a class="nav-link" href="<?php echo e(route('currency.index')); ?>">
          Mata Uang
        </a>
      </li>
      <li>
        <a class="nav-link" href="<?php echo e(route('account.index')); ?>  ">
          Rekening
        </a>
      </li>
    </ul>
  </li>  

  
  <li class="menu-header">Slip</li>
  <li>
    <a class="nav-link" href="<?php echo e(route('placing.index')); ?>">
      <i class="far fa-file-alt"></i> 
      <span>Placing Slip</span>
    </a>
  </li>
  <li>
    <a class="nav-link" href="<?php echo e(route('quotation.index')); ?>">
      <i class="far fa-file-alt"></i> 
      <span>Quotation Slip</span>
    </a>
  </li>
  <li>
    <a class="nav-link" href="credits.html">
      <i class="fas fa-file-invoice"></i> 
      <span>Invoice</span>
    </a>
  </li>
  <li>
    <a class="nav-link" 
    
    >
      <i class="far fa-file-alt"></i> 
      <span>Instruct Cover</span>
    </a>
  </li>
  <li>
    <a class="nav-link" href="credits.html">
      <i class="far fa-file"></i> 
      <span>Report</span>
    </a>
  </li>

  <li class="menu-header">Tools</li>
  <li class="nav-item dropdown">
    <a href="#" class="nav-link has-dropdown">
      <i class="fas fa-tools"></i>
      <span>Tools</span>
    </a>
    <ul class="dropdown-menu">
      <li>
        <a class="nav-link" href="index-0.html">
          Kalkulator
        </a>
      </li>
      <li>
        <a class="nav-link" href="index.html">
          Konversi Kurs
        </a>
      </li>
    </ul>
  </li>  
</ul>

<div class="mt-4 mb-4 p-3 hide-sidebar-mini">
  
  
</div>
<?php /**PATH /var/www/html/broker-system/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>