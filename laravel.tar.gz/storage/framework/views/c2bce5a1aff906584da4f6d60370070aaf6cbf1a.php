<?php $__env->startSection('content'); ?>
<section class="section">
   <div class="section-body">
      <div class="row">
         <div class="col-12">
         <div class="card">

            <div class="card-header">
               <div class="col-sm-12 col-md-6 text-left">
                  <h4>Rubah Data Pemberi Tanda Tangan </h4>
               </div>
               <div class="col-sm-12 col-md-6 text-right">
               <strong><?php echo e($item->nama); ?> </strong>
            </div>
            </div>

            <div class="card-body">
               <form action="<?php echo e(route('authorize_sign.update', $item->id)); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <?php echo method_field('PATCH'); ?>
               <div class="col-12">
                  <div class="form-row">

                     <div class="form-group col-md-6">
                        <label for="name">Kode</label>
                        <input type="text" 
                           class="form-control" 
                           name="input_kode" 
                           id="input_kode" 
                           value="<?php echo e(old('input_kode')?old('input_kode'): $item->input_kode); ?> <?php $__errorArgs = ['input_kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                           <?php $__errorArgs = ['input_kode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="text-muted"><?php echo e($message); ?> </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     
                  </div>

                  <div class="form-row">

                     <div class="form-group col-md-7">
                        <label for="phone">Nama</label>
                        <input type="text" 
                           class="form-control" 
                           name="nama" 
                           id="nama" 
                           value="<?php echo e(old('nama')?old('nama'): $item->nama); ?> <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                           <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="text-muted"><?php echo e($message); ?> </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>

                  </div>

                  <div class="form-row">

                     <div class="form-group col-md-6">
                        <label for="name">Jabatan</label>
                        <input type="text" 
                           class="form-control" 
                           name="jabatan" 
                           id="jabatan" 
                           value="<?php echo e(old('jabatan')?old('jabatan'): $item->jabatan); ?> <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                           <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <div class="text-muted"><?php echo e($message); ?> </div>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                     </div>
                     
                  </div>
               </div>
               <button type="submit" class="btn btn-primary float-right">Simpan</button>

               </form>
            </div>
         </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/broker-system/resources/views/pages/authorize_sign/edit.blade.php ENDPATH**/ ?>