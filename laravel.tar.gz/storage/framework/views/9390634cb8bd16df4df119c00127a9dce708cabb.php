<?php $__env->startSection('content'); ?>
<section class="section">
   <div class="section-body">

      <div class="row">
         <div class="col-12">
         <div class="card">

            
            <div class="card-header">
               <div class="col-sm-12 col-md-6">
               <h4>Daftar No. Rekening</h4>
               </div>
               <div class="col-sm-12 col-md-6">
               <a href="<?php echo e(route('account.create')); ?> " 
                  class="btn btn-light float-right" >
                  Tambah
               </a> 
               </div>
            </div>

            
            <div class="card-body">
               <div class="table-responsive">
                  <table class="table table-striped" id="table-1">
                     <thead>
                        <tr>
                           <th>No</th>
                           <th>Nama Bank</th>
                           <th>No. Rekening</th>
                           <th>a/n</th>
                           <th>Tindakan</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                           <td><?php echo e($item->id); ?></td>
                           <td><?php echo e($item->nama_bank); ?></td>
                           <td><?php echo e($item->no_rekening); ?></td>
                           <td><?php echo e($item->atas_nama); ?></td>
                           <td>
                              <a class="btn btn-sm  btn-light" 
                                 href="<?php echo e(route('account.edit', $item->id)); ?> ">
                                 Edit
                              </a>
                           </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                        <td colspan="8" class="text-center p-4">
                              Data tidak tersedia
                        </td>
                        </tr>
                        <?php endif; ?>
                     
                     
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         </div>
      </div>
   </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script>
$("#table-1").dataTable({
"columnDefs": [
   { "sortable": false, "targets": [2,3] }
]
});
</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/broker-system/resources/views/pages/account/index.blade.php ENDPATH**/ ?>