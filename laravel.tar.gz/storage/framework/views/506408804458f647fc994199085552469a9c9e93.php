<?php $__env->startSection('content'); ?>
<section class="section">
   <div class="section-body">
      <div class="row">
         <div class="col-12">
            <div class="card">

               <div class="card-header">
                  <h4>Buat Placing Slip</h4>
               </div>

               <div class="card-body">
                  <form action="<?php echo e(route('placing.store')); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                     <div class="col-12">
                        <div class="form-row">
                           <input type="hidden" value="DRAFT"  name="status">

                           
                           <div class="form-group col-md-6">
                              <label>Lembaga Asuransi</label>
                              <select name="insurance_id"
                                 class="form-control select2 <?php $__errorArgs = ['insurance_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is_invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                 style="border-color: #ced4da !important" >

                                 <option value="">--Pilih Lembaga Asuransi--</option>
                                 <option value="0">First Class Insurance Company</option>
                                 <?php $__currentLoopData = $insurances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($insurance->id); ?>">
                                       <?php echo e($insurance->name); ?>

                                    </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>

                           
                           <div class="form-group col-md-6">
                              <label>Pihak Tertanggung</label>
                              <select name="client_id"
                                 class="form-control select2 <?php $__errorArgs = ['client_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is_invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                 <option value="">--Pilih Pihak Tertanggung--</option>
                                 <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>">
                                       <?php echo e($client->name); ?>

                                    </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>

                        
                        <div class="form-row">
                           <div class="form-group col-md-2">
                              <label for="inputEmail3" class="col-form-label">
                                 Period of insurance
                              </label>
                           </div>

                           <div class="form-group col-md-5">
                              <label class="col-form-label">
                                 From
                              </label>

                              <input type="date" 
                                 name="period_from"
                                 class="form-control datepicker" 
                                 placeholder="Periode dari"
                                 value="<?php echo e(old('period_from')); ?> <?php $__errorArgs = ['period_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">  
                              <?php $__errorArgs = ['period_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <div class="text-muted"><?php echo e($message); ?> </div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                           </div>

                           <div class="form-group col-md-5">
                              <label class="col-form-label">to</label>

                              <input type="date" 
                                 name="period_to"
                                 class="form-control datepicker" 
                                 placeholder="hingga"
                                 value="<?php echo e(old('period_to')); ?> <?php $__errorArgs = ['period_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> "> 
                              <?php $__errorArgs = ['period_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <div class="text-muted"><?php echo e($message); ?> </div>
                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                        </div>

                        <div class="form-row">

                           
                           <div class="form-group col-md-6">
                              <label>Type of Cover</label>
                              <select name="cover_type_id" 
                                 class="form-control select2 <?php $__errorArgs = ['cover_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is_invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" >
                                 <option value="">--Pilih Jenis Asuransi--</option>
                                 <?php $__currentLoopData = $covertypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $covertype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($covertype->input_kode); ?>">
                                       <?php echo e($covertype->deskripsi); ?>

                                    </option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                           </div>
                        </div>

                        <div class="form-row">
                        
                           
                           <div class="form-group col-md-4">
                              <label>Jenis Mata Uang</label>
                              <div class="input-group mb-3">
                                 <select name="currency_id" 
                                    class="form-control select2 <?php $__errorArgs = ['insurance_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is_invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">--Pilih Jenis Mata Uang--</option>
                                    <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <option value="<?php echo e($currency->input_kode); ?>">
                                          <?php echo e($currency->input_kode); ?> - <?php echo e($currency->mata_uang); ?>

                                       </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 </select>
                              </div>
                           </div>

                           
                           <div class="form-group col-md-2">
                              <label>Compensation</label>
                              <div class="input-group mb-3">
                                 <input type="number" 
                                    name="compensation"
                                    class="form-control" 
                                    aria-label="Amount (to the nearest dollar)"
                                    value="<?php echo e(old('compensation')); ?> <?php $__errorArgs = ['compensation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                 <?php $__errorArgs = ['compensation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-muted"><?php echo e($message); ?> </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                 </div>
                              </div>
                           </div>

                           <div class="form-group col-md-2">
                              <label>Premium Warranty</label>
                              <div class="input-group mb-3">
                                 <input type="number" 
                                    name="premium_warranty"
                                    class="form-control" 
                                    aria-label="Amount (to the nearest dollar)"
                                    value="<?php echo e(old('premium_warranty')); ?> <?php $__errorArgs = ['premium_warranty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                                 <?php $__errorArgs = ['premium_warranty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-muted"><?php echo e($message); ?> </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                 <div class="input-group-append">
                                    <span class="input-group-text">days</span>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="form-row">
                        
                           <div class="form-group col-md-12">
                              <label>Premi (Rate * Sum Insured = Premi)</label>
                              <div class="input-group md-10">
                                 
                                 <input type="number" 
                                    id="rate"
                                    name="rate"
                                    class="form-control" 
                                    placeholder="Rate/Premium"
                                    >
                                 <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-muted"><?php echo e($message); ?> </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                 <div class="input-group-append">
                                    <span class="input-group-text">x</span>
                                 </div>

                                 
                                 <input type="number" 
                                    id="sum_insured"
                                    name="sum_insured"
                                    class="form-control" 
                                    placeholder="Sum Insured">
                                 <?php $__errorArgs = ['sum_insured'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-muted"><?php echo e($message); ?> </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                 <div class="input-group-append">
                                    <input type="button" value="Hitung Premi" onclick="result();" >
                                    
                                 </div>

                                 
                                 <input type="number" 
                                    id="res"
                                    name="premi"
                                    class="form-control" 
                                    placeholder="Premi"
                                    />
                                 <?php $__errorArgs = ['premi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-muted"><?php echo e($message); ?> </div>
                                 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              </div>
                              
                           </div>
                        </div>

                        <div class="form-group ">
                           <label class="col-form-label ">Content</label>
                           <textarea name="content"
                              class="summernote <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                              <?php echo e(old('content')); ?>

                           </textarea>
                           <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-muted"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                     </div>
                     <button type="submit" class="btn btn-primary float-right">Save as Draft</button>

                  </form>
                  
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-script'); ?>
<script>
   var d1 = 0;
   var d2 = 0;

   function reset(){
      output = '';
      data.length = 0;

      document.getElementById('rate').value = output;
      document.getElementById('res').innerHTML = output;
      document.getElementById('rate').focus()
   }

   function result() {
      d1 = parseFloat(document.getElementById('rate').value);
      d2 = parseFloat(document.getElementById('sum_insured').value);

      var res = d1*d2;

      document.getElementById('res').value = res;
      
   }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/broker-system/resources/views/pages/placing/create.blade.php ENDPATH**/ ?>