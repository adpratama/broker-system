<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo e(asset('fonts/feather.svg')); ?> ">
    <title>Pialang System</title>
    <!-- Simple bar CSS -->
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body class="vertical  light  ">
    <div id="app">
      <div class="main-wrapper">
        

        
        <nav class="navbar navbar-expand-lg main-navbar">
          <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>

        
        <div class="main-sidebar">
          <aside id="sidebar-wrapper">
            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
          </aside>
        </div>
  
        <!-- Main Content -->
        <div class="main-content">
          <?php echo $__env->yieldContent('content'); ?>
        </div>

        
        <footer class="main-footer">
          <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
      </div>
    </div>

    <?php echo $__env->yieldPushContent('before-script'); ?>
    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('after-script'); ?>

  </body>
</html><?php /**PATH /var/www/html/broker-system/resources/views/layouts/default.blade.php ENDPATH**/ ?>