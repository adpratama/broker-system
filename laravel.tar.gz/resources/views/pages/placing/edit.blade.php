@extends('layouts.default')
@section('content')
<section class="section">
   <div class="section-body">
      <div class="row">
         <div class="col-12">
            <div class="card">

               <div class="card-header">
                  <div class="col-sm-12 col-md-6">
                     <h4>Edit Data Placing Slip No. {{$item->id}} </h4>
                  </div>
                  <div class="col-sm-12 col-md-6 text-right">
                     <a href="{{ route('placing.status', $item->id) }}?status=REJECTED" 
                        type="button" 
                        class="btn btn-danger " >
                        Reject
                     </a>
                     <a href="{{ route('placing.status', $item->id) }}?status=APPROVED" 
                        type="button" 
                        class="btn btn-primary " >
                        Approve
                     </a> 
                  </div>
               </div>

               <div class="card-body">
                  <form action="{{ route('placing.update', $item->id) }}" method="POST">
                     @csrf     
                     @method('PUT')
                     <div class="col-12">
                        <div class="form-row">

                           {{-- Input Lembaga Asuransi --}}
                           <div class="form-group col-md-6">
                              <label>Lembaga Asuransi</label>
                              <select class="form-control select2" 
                                 style="border-color: #ced4da !important" >

                                 <option value="">--Pilih Lembaga Asuransi--</option>
                                 <option value="0">First Class Insurance Company</option>
                                 @foreach ($insurances as $insurance)
                                    <option value="{{ $insurance->id }}">
                                       {{ $insurance->name }}
                                    </option>
                                 @endforeach
                              </select>
                           </div>

                           {{-- Input Pihak Tertanggung --}}
                           <div class="form-group col-md-6">
                              <label>Pihak Tertanggung</label>
                              <select class="form-control select2">

                                 <option value="">--Pilih Pihak Tertanggung--</option>
                                 @foreach ($insuredss as $insureds)
                                    <option value="{{ $insureds->id }}">
                                       {{ $insureds->name }}
                                    </option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        {{-- Input Periode Asuransi --}}
                        <div class="form-row">
                           <div class="form-group col-md-2">
                              <label for="inputEmail3" class="col-form-label">
                                 Period of insurance
                              </label>
                           </div>

                           <div class="form-group col-md-5">
                              <label class="col-form-label">
                                 From
                              </label>

                              <input type="date" 
                                 name="period-from"
                                 class="form-control datepicker" 
                                 placeholder="Periode dari">   
                           </div>

                           <div class="form-group col-md-5">
                              <label class="col-form-label">to</label>

                              <input type="date" 
                                 name="period-to"
                                 class="form-control datepicker" 
                                 placeholder="Periode dari"> 
                           </div>
                        </div>

                        <div class="form-row">

                           {{-- Input Jenis Asuransi --}}
                           <div class="form-group col-md-6">
                              <label>Type of Cover</label>
                              <select class="form-control select2" >
                                 <option value="">--Pilih Jenis Asuransi--</option>
                                 <option value="0">First Class Insurance Company</option>
                                 @foreach ($insurances as $insurance)
                                    <option value="{{ $insurance->id }}">
                                       {{ $insurance->name }}
                                    </option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        <div class="form-row">
                        
                           {{-- Input Jenis Mata Uang --}}
                           <div class="form-group col-md-4">
                              <label>Jenis Mata Uang</label>
                              <div class="input-group mb-3">
                                 <select class="form-control select2">
                                    <option value="">--Pilih Jenis Mata Uang--</option>
                                    @foreach ($insuredss as $insureds)
                                       <option value="{{ $insureds->id }}">
                                          {{ $insureds->name }}
                                       </option>
                                    @endforeach
                                 </select>
                              </div>
                           </div>

                           {{-- Input Compensation --}}
                           <div class="form-group col-md-2">
                              <label>Compensation</label>
                              <div class="input-group mb-3">
                                 <input type="number" 
                                    class="form-control" 
                                    aria-label="Amount (to the nearest dollar)">
                                 <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                 </div>
                              </div>
                           </div>

                           <div class="form-group col-md-2">
                              <label>Premium Warranty</label>
                              <div class="input-group mb-3">
                                 <input type="number" 
                                    class="form-control" 
                                    aria-label="Amount (to the nearest dollar)">
                                 <div class="input-group-append">
                                    <span class="input-group-text">days</span>
                                 </div>
                              </div>
                           </div>
                        </div>

                        <div class="form-row">
                        
                           <div class="form-group col-md-12">
                              <label>Premi (Rate * Sum Insured = Premi)</label>
                              <div class="input-group md-10">
                                 {{-- Input Rate/Premium --}}
                                 <input type="number" 
                                    class="form-control" 
                                    placeholder="Rate/Premium">
                                 <div class="input-group-append">
                                    <span class="input-group-text">x</span>
                                 </div>

                                 {{-- Input Sum Insured --}}
                                 <input type="number" 
                                    class="form-control" 
                                    placeholder="Sum Insured">
                                 <div class="input-group-append">
                                    <span class="input-group-text">=</span>
                                 </div>

                                 {{-- Input Premi --}}
                                 <input type="number" 
                                    class="form-control" 
                                    placeholder="Premi">
                              </div>
                           </div>
                        </div>
                        
                        <div class="form-group ">
                           <label class="col-form-label ">Content</label>
                           <textarea class="summernote"></textarea>
                        </div>
                     </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
@endsection

@push('after-script')

@endpush